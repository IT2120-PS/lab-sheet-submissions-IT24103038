#set working directory
setwd("C:/Users/it24103038/Desktop/IT24103038")

#Question 1
#import file
branch_data<-read.table("Exercise.txt", header = TRUE, sep = ",")

#Question 2
#open file in new window
fix(branch_data)

#check variable type and scale of measurement
str(branch_data)

#Question 3
#boxplot for sales
boxplot(branch_data$Sales_X1,
        main = "Boxplot of sales data",
        ylab = "Sales",
        col = "pink",
        horizontal = FALSE)

#Question 4
#Five-Number Summary for Advertising
print(summary(branch_data$Advertising_X2))

#IQR for Advertising
print(IQR(branch_data$Advertising_X2))

#Question 5
#function to find outlier
find_outlier<-function(x){
  Q1<-quantile(x, 0.25)
  Q3<-quantile(x, 0.75)
  IQR_val<- Q3 - Q1
  lower_bound<- Q1 - 1.5 * IQR_val
  upper_bound<- Q3 + 1.5 * IQR_val
  x[x<lower_bound | x>upper_bound]
}

#find outliers in years
print(find_outlier(branch_data$Years_X3))
